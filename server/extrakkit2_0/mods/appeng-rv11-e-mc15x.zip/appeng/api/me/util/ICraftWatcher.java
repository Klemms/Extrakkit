package appeng.api.me.util;

/**
 * Not used.
 *
 */
public interface ICraftWatcher {
	
	void markChainCrafted();
	void markComplete( ICraftRequest cr );
	
}
